# Compilation and Execution instructions

## Python

 Requirements:
 - Python
 - Pygame
 - Pygame_menu

 Run the game:
 - `python main.py`

 In order to run the test function uncomment lines 219 and 220, and comment 215-218. The number of simulated games is customizable and the depth and evaluation functions can also be changed. When using the MCTS the time of search is passed as a parameter as shown in line 219.


